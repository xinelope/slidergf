<?php
defined('_JEXEC') or die;
require_once(JModuleHelper::getLayoutPath('mod_slidergf'));
?>
